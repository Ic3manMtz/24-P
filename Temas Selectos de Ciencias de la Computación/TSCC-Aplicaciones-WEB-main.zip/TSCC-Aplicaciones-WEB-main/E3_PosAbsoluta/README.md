Ejemplo del uso que se le puede dar a la propiedad de la posición absoluta
