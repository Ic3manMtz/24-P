Ejemplo del modelo de cajas flexible
