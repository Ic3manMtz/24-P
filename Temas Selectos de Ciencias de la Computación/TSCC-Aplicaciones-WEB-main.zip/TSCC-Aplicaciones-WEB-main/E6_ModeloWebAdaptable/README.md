Ejemplo de diseño web adaptable
