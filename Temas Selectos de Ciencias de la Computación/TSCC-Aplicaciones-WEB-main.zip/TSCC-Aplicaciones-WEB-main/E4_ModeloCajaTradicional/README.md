Ejemplo del modelo de cajas tradicional
