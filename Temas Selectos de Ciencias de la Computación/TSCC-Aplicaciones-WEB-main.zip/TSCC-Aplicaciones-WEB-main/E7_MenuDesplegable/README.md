Ejemplo de menú desplegabla para nuestro diseño web adaptable
