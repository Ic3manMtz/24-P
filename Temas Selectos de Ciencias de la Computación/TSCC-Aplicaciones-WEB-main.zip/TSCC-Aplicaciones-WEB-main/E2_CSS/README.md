Ejemplo de las diferentes formas de referencial elementos con CSS
