Ejemplo para almacenar información con localStorage cookies.
Para probar este ejemplo debe colocar la página en un servidor. Puede ser un servidor local como XAMPP
