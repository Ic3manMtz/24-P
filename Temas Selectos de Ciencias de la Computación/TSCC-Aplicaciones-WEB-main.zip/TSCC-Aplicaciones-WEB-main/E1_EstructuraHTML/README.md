Ejemplo de las diferentes secciones que puede contener la estructura de HTML
